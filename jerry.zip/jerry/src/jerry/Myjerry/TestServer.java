package jerry.Myjerry;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServer {
	
	//���apps�ľ���·��
	public static String WEB_HOME=System.getProperty("user.dir")+"\\"+"webapps";
	//���徲̬���������ڴ�ű�������ľ�̬ҳ������
	private static String url="";
	public static void main(String[] args) throws Exception{
		ServerSocket serversocket = null;
		Socket socket = null;
		InputStream is = null;
		OutputStream ops = null; 
		try {
			serversocket = new ServerSocket(8080);
			while(true) {
				socket = serversocket.accept();
				is = socket.getInputStream();
				ops = socket.getOutputStream();
				parse(is);
				sendStaticResource(ops);
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(null!=is) {
				is.close();
				is=null;
			}
			if(null!=ops) {
				ops.close();
				ops=null;
			}
			if(null!=socket) {
				socket.close();
				socket=null;
			}
		}
		
	}
	//���;�̬��Դ
	private static void sendStaticResource(OutputStream ops) throws Exception{
		byte[] buffer = new byte[2048];
		
		FileInputStream fis = null;
		
		try {
			File file = new File(WEB_HOME,url);
			if(file.exists()) {
				ops.write("HTTP/1.1 200 OK\n".getBytes());
				ops.write("Server:apache-Coyote/1.1\n".getBytes());
				ops.write("Content-Type:text/html;charset=utf-8\n\n".getBytes());
				fis = new FileInputStream(file);
				int ch = fis.read(buffer);
				while(ch!=-1) {
					ops.write(buffer,0,ch);
					ch = fis.read(buffer);
				}
			}else {
				ops.write("HTTP/1.1 404 not found\n".getBytes());
				ops.write("Server:apache-Coyote/1.1\n".getBytes());
				ops.write("Content-Type:text/html;charset=utf-8\n\n".getBytes());
				String errorMessage="file not found";
				ops.write(errorMessage.getBytes());
			}
		}catch(Exception e) {
			
		}finally {
			if(null!=fis) {
				fis.close();
				fis=null;
			}
		}
	}
	//��ȡ���󲿷��� ������Դ������
	private static void parse(InputStream is) throws Exception {
		StringBuffer content = new StringBuffer();
		
		byte[] buffer = new byte[2048];
		
		int l=-1;
		
		l=is.read(buffer);
		
		for(int i=0;i<l;i++) {
			content.append((char)buffer[i]);
		}
		parseUrl(content.toString());
	}
	private static void parseUrl(String string) {
		int index1,index2 = 0;
		index1=string.indexOf(" ");
		if(index1!=-1) {
			index2=string .indexOf(" ",index1+1);
		}
		if(index2>index1) {
			url = string.substring(index1+2, index2); 
		}
	}
	
}
