package jerry.Myjerryv2;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Aservlet implements Servlet{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("A init");
	}

	@Override
	public void service(InputStream is, OutputStream ops) throws IOException{
		// TODO Auto-generated method stub
		ops.write("!".getBytes());
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("A destroy");
	}
	
}
