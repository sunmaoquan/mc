package Bean;

import java.sql.ResultSet;
import java.sql.SQLException;


public class Disbean {
		private String cla;
		private int num;
		private String name;
		private String dingwei;
		private String jiepao;
		private String cifa;
		private String zhuzhi;
		private String x;
		private String y;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDingwei() {
			return dingwei;
		}
		public void setDingwei(String dingwei) {
			this.dingwei = dingwei;
		}
		public String getJiepao() {
			return jiepao;
		}
		public void setJiepao(String jiepao) {
			this.jiepao = jiepao;
		}
		public String getCifa() {
			return cifa;
		}
		public void setCifa(String cifa) {
			this.cifa = cifa;
		}
		public String getZhuzhi() {
			return zhuzhi;
		}
		public void setZhuzhi(String zhuzhi) {
			this.zhuzhi = zhuzhi;
		}
		public int getNum() {
			return num;
		}
		public void setNum(int num) {
			this.num = num;
		}
		public String getCla() {
			return cla;
		}
		public void setCla(String cla) {
			this.cla = cla;
		}
		public String getX() {
			return x;
		}
		public void setX(String x) {
			this.x = x;
		}
		public String getY() {
			return y;
		}
		public void setY(String y) {
			this.y = y;
		}
		public void set(ResultSet rs) throws SQLException{
			setName(rs.getString("name"));
			setDingwei(rs.getString("dingwei"));
			setJiepao(rs.getString("jiepao"));
			setCifa(rs.getString("cifa"));
			setZhuzhi(rs.getString("zhuzhi"));
			setX(rs.getString("x"));
			setY(rs.getString("y"));
			setNum(rs.getInt("num"));
		}
}
