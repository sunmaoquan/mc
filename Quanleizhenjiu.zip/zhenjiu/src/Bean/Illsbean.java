package Bean;

public class Illsbean {
	private String name;
	private String zhenfa;
	private int illcla;
	private String illsclaname;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getZhenfa() {
		return zhenfa;
	}
	public void setZhenfa(String zhenfa) {
		this.zhenfa = zhenfa;
	}
	public int getIllcla() {
		return illcla;
	}
	public void setIllcla(int illcla) {
		this.illcla = illcla;
	}
	public String getIllsclaname() {
		return illsclaname;
	}
	public void setIllsclaname(String illsclaname) {
		this.illsclaname = illsclaname;
	}
	
}
