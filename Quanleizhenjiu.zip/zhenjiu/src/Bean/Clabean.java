package Bean;

public class Clabean {
	private String clasname;
	private int num;
	private int count;
	public String getClasname() {
		return clasname;
	}
	public void setClasname(String clasname) {
		this.clasname = clasname;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

}
