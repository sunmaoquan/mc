package zhenjiu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

import Utils.DBUtil_BO;

public class resgist extends HttpServlet {
	
	public resgist() {
		super();
	}

	public void destroy() {
		super.destroy();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String user = request.getParameter("user");
		String pass1 = request.getParameter("pass1");
		String pass2 = request.getParameter("pass2");
		
		HttpSession session = request.getSession();
		
		if(pass1.equals(pass2)==false){
			session.setAttribute("warning","�����������벻һ��");
			request.getRequestDispatcher("/resgist.jsp").forward(request, response);
		}
		else if(p(pass1)==false){
			session.setAttribute("warning", "����Ӧ��5~18λ��ĸ���������");
			request.getRequestDispatcher("/resgist.jsp").forward(request, response);
		}else if(p2(user)){
			session.setAttribute("warning", "�û����Ѵ���");
			request.getRequestDispatcher("/resgist.jsp").forward(request, response);
		}else{
			try {
				DBUtil_BO db = new DBUtil_BO();
				db.getSt("insert into users values(?,?)");
				db.st.setString(1,user);
				db.st.setString(2,pass1);
				db.st.executeUpdate();
				session.setAttribute("warning",null);
				db.realseSource();
				request.getRequestDispatcher("/index.jsp").forward(request, response);
			} catch (Exception e) {
				session.setAttribute("warning", "����ʧ�ܣ�������");
				request.getRequestDispatcher("/resgist.jsp").forward(request, response);
				e.printStackTrace();
			}
		}
	}
	public static boolean p(String s) {
		return s.matches("[a-zA-Z0-9]{5,18}");
	}
	public boolean p2(String s){
		try {
			DBUtil_BO db = new DBUtil_BO();
			db.getRs("select user from users");
			while(db.rs.next()){
				if(db.rs.getString(1).equals(s)){
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public void init() throws ServletException {
		
	}

}
