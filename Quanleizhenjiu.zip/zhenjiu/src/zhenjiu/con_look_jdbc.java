package zhenjiu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.Conbean;
import Utils.DBUtil_BO;

public class con_look_jdbc extends HttpServlet {
	
	public con_look_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		 
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		
		DBUtil_BO db = new DBUtil_BO();
		
		try{
			db.getRs("select * from con order by ill");
		}catch(Exception e){
			System.out.println("���ݿ��ѯ���� ");
		}
		List<Conbean> conlist = new ArrayList<Conbean>();
		List<String> condislist = new ArrayList<String>();
		List<String> conilllist = new ArrayList<String>();
		try{
			while(db.rs.next()){
				Conbean conbean = new Conbean();
				conbean.setIllname(db.rs.getString("ill"));
				conbean.setDisname(db.rs.getString("dis"));
				if(db.rs.getInt("level")==1){
					conbean.setLevelname("��Ѩ");
				}else{
					conbean.setLevelname("��Ѩ");
				}
				conlist.add(conbean);
			}
			db.getRs("select name from dis order by num");
			while(db.rs.next()){
				String dis = db.rs.getString("name");
				condislist.add(dis);
			}
			db.getRs("select ill from ills order by illcla");
			while(db.rs.next()){
				String ill = db.rs.getString("ill");
				conilllist.add(ill);
			}
		}catch(Exception e){
			System.out.println("�������������");
		}
		
		session.setAttribute("conlist",conlist);
		session.setAttribute("condislist",condislist);
		session.setAttribute("conilllist",conilllist);
		
		try {
			db.realseSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("/rot_con.jsp").forward(request, response);
	}
	public void init() throws ServletException {
		
	}

}
