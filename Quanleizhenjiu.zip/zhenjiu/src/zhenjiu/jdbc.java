package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import Bean.Clabean;
import Bean.Disbean;
import Utils.DBUtil_BO;

/**
 * Servlet implementation class jdbc
 */
@WebServlet("/jdbc")
public class jdbc extends HttpServlet {

	public jdbc() {
		super();
	}

	
	public void destroy() {

	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DBUtil_BO db = new DBUtil_BO();
		DBUtil_BO db2 = new DBUtil_BO();
		try {
			db.getRs("select * from cla order by clasnum");
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Clabean> clalist = new ArrayList<Clabean>();
		List<Disbean> classlist = new ArrayList<Disbean>();
		if(db.rs!=null){
		
				try {
					while(db.rs.next()){
						Clabean  clabean = new Clabean();
						clabean.setClasname(db.rs.getString("clas"));
						clabean.setNum(db.rs.getInt("clasnum"));
						db2.getRs("select count(num) from dis where num ="+db.rs.getInt("clasnum"));
						while(db2.rs.next()){
						int coun = db2.rs.getInt(1);
						clabean.setCount(coun);}
						clalist.add(clabean);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		try {
			db.getRs("select * from dis order by num");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if(db.rs!=null){
			try {
				while(db.rs.next()){
					Disbean disbean = new Disbean();
					disbean.set(db.rs);
					classlist.add(disbean);
				}
				
			request.setCharacterEncoding("utf-8");
				 
			response.setCharacterEncoding("utf-8");
			
			HttpSession session = request.getSession();
			 
			session.setAttribute("classlist", classlist);
			
			session.setAttribute("clalist", clalist);
			
			try {
				db.realseSource();
				db2.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			response.sendRedirect("/zhenjiu/two.jsp");
			//request.getRequestDispatcher("/two.jsp").forward(request,response);
				 
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void init() throws ServletException {

	}

}
