package zhenjiu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.Illclabean;
import Utils.DBUtil_BO;

public class illcla_look_jdbc extends HttpServlet {

	public illcla_look_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		 
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		
		DBUtil_BO db = new DBUtil_BO();
		List<Illclabean> illclalist = new ArrayList<Illclabean>();
		try{
			db.getRs("select * from illcla order by illsclanum");
			while(db.rs.next()){
				Illclabean illclabean = new Illclabean();
				illclabean.setName(db.rs.getString("illscla"));
				illclalist.add(illclabean);
			}
		}catch(Exception e){
			System.out.println("��ѯ����");
		}
		session.setAttribute("illclalist", illclalist);
		try {
			db.realseSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("/rot_illcla.jsp").forward(request,response);
	}
	public void init() throws ServletException {
		
	}

}
