package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Utils.DBUtil_BO;


public class illcla_add_jdbc extends HttpServlet {
	
	public illcla_add_jdbc() {
		super();
	}
	public void destroy() {

	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String illclaname = request.getParameter("illclaname");
		DBUtil_BO db = new DBUtil_BO();
		int illclanum = 0;
		try{
			db.getRs("select max(illsclanum) as num from illcla");
			while(db.rs.next()){
				illclanum = db.rs.getInt("num")+1;
			}
		}catch(Exception e){
			System.out.println("��ѯʧ��");
		}
		try{
			db.getSt("insert into illcla values(?,?)");
			db.st.setString(1,illclaname);
			db.st.setInt(2,illclanum);
			db.getRs();
		}catch(Exception e){
			System.out.println("����ʧ��");
		}
		try {
			db.realseSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("illcla_look_jdbc").forward(request, response);
	}
	public void init() throws ServletException {
		
	}

}
