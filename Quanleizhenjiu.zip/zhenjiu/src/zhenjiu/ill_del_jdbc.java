package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

import Utils.DBUtil_BO;

public class ill_del_jdbc extends HttpServlet {
	
	public ill_del_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
			String illname = request.getParameter("illname");
			
			DBUtil_BO db = new DBUtil_BO();
			
			try{
				db.getSt("delete from ills where ill=?");
				db.st.setString(1,illname);
				db.getRs();
			}catch(Exception e){
				System.out.println("ɾ��ʧ��");
			}
			
			try {
				db.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("ill_look_jdbc").forward(request, response);
	}
	public void init() throws ServletException {
		
	}

}
