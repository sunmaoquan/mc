package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import Bean.Conbean;
import Bean.Disbean;
import Bean.Illclabean;
import Bean.Illsbean;
import Utils.DBUtil_BO;
@WebServlet("/illjdbc")
public class illjdbc extends HttpServlet {

	public illjdbc() {
		super();
	}

	public void destroy() {
		super.destroy(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		
		List<Illsbean> Ills = new ArrayList<Illsbean>();
		List<Illclabean> Illcla = new ArrayList<Illclabean>();
		List<Disbean> dis = new ArrayList<Disbean>();
		List<List<Conbean>> con = new ArrayList<List<Conbean>>();
		try{
			//�������ർ��
			DBUtil_BO db = new DBUtil_BO();
			DBUtil_BO db2 = new DBUtil_BO();
			DBUtil_BO db3 = new DBUtil_BO();
			db.getRs("select * from illcla order by illsclanum");
			while(db.rs.next()){
				Illclabean illclabean = new Illclabean();
				illclabean.setName(db.rs.getString("illscla"));
				illclabean.setNum(db.rs.getInt("illsclanum"));
				//ÿ�༲������������Ŀ
				db2.getRs("select count(ill) from ills where illcla ="+db.rs.getInt("illsclanum"));
				while(db2.rs.next()){
					illclabean.setCount(db2.rs.getInt(1));
				}
				Illcla.add(illclabean);
			}
			session.setAttribute("Illcla", Illcla); 
			//��������  ����-Ѩλ��ϵ����
			db.getRs("select * from ills order by illcla");
			while(db.rs.next()){
				Illsbean illsbean = new Illsbean();
				String name = db.rs.getString("ill");
				illsbean.setName(name);
				db2.getRs("select * from con where ill='"+name+"' order by level");
				List<Conbean> Listcon = new ArrayList<Conbean>();
				while(db2.rs.next()){
					Conbean conbean = new Conbean();
					conbean.setDisname(db2.rs.getString("dis"));
					db3.getRs("select * from dis where name='"+db2.rs.getString("dis")+"'");
					while(db3.rs.next()){
						conbean.setX(db3.rs.getString("x"));
						conbean.setY(db3.rs.getString("y"));
					}
					conbean.setIllname(db2.rs.getString("ill"));
					conbean.setLevel(db2.rs.getInt("level"));
					Listcon.add(conbean);
				}
				con.add(Listcon);
				illsbean.setZhenfa(db.rs.getString("zhenfa"));
				illsbean.setIllcla(db.rs.getInt("illcla"));
				Ills.add(illsbean);
			}
			session.setAttribute("Ills", Ills);
			session.setAttribute("con", con);
			//Ѩλ����
			db.getRs("select * from dis order by num");
			while(db.rs.next()){
				Disbean disbean = new Disbean();
				disbean.set(db.rs);
				dis.add(disbean);
			}
			session.setAttribute("dis", dis);
			db.realseSource();
			db2.realseSource();
			db3.realseSource();
			response.sendRedirect("/zhenjiu/one.jsp");
		}catch(Exception e){
			System.out.println("������");
		}
	}

	public void init() throws ServletException {

	}

}
