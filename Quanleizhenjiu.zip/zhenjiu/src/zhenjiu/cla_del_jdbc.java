package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Utils.DBUtil_BO;

public class cla_del_jdbc extends HttpServlet {

	public cla_del_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
			String claname  = request.getParameter("claname");
			DBUtil_BO db = new DBUtil_BO();
			try{
				db.getSt("delete from cla where clas=?");
				db.st.setString(1,claname);
				db.getRs();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			try {
				db.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("cla_look_jdbc").forward(request,response);
	}
	public void init() throws ServletException {
		
	}

}
