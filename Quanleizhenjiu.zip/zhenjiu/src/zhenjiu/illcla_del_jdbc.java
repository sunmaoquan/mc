package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

import Utils.DBUtil_BO;

public class illcla_del_jdbc extends HttpServlet {
	
	public illcla_del_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
			String illclaname = request.getParameter("illclaname");
			DBUtil_BO db = new DBUtil_BO();
			try{
				db.getSt("delete from illcla where illscla=?");
				db.st.setString(1,illclaname);
				db.getRs();
			}catch(Exception e){
				System.out.println("ɾ��ʧ��");
			}
			try {
				db.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.getRequestDispatcher("illcla_look_jdbc").forward(request, response);
	}
	public void init() throws ServletException {
		
	}

}
