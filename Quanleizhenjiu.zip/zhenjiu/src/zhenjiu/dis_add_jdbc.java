package zhenjiu;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

import Utils.DBUtil_BO;


public class dis_add_jdbc extends HttpServlet {
	
	public dis_add_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
			String disname  = request.getParameter("disname");
			String disdingwei = request.getParameter("disdingwei");
			String disjiepao = request.getParameter("disjiepao");
			String discifa = request.getParameter("discifa");
			String diszhuzhi = request.getParameter("diszhuzhi");
			String discla = request.getParameter("discla");
			String disx = request.getParameter("disx");
			String disy = request.getParameter("disy");
			DBUtil_BO db = new DBUtil_BO();
			int disclanum = 0;
			try {
				db.getRs("select * from cla where clas = '"+discla+"'");
				while(db.rs.next()){
					disclanum=db.rs.getInt("clasnum");
				}
			db.getSt("insert into dis values(?,?,?,?,?,?,?,?)");
			db.st.setInt(1,disclanum);
			db.st.setString(2,disname);
			db.st.setString(3,disdingwei);
			db.st.setString(4,disjiepao);
			db.st.setString(5,discifa);
			db.st.setString(6,diszhuzhi);
			db.st.setString(7,disx);
			db.st.setString(8,disy);  
			db.getRs();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			try {
				db.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("dis_look_jdbc").forward(request,response);
	}
	public void init() throws ServletException {
		
	}

}
