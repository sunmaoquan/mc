package zhenjiu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

import Utils.DBUtil_BO;

public class con_upd_jdbc extends HttpServlet {
	
	public con_upd_jdbc() {
		super();
	}
	public void destroy() {
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String illoldname = request.getParameter("illoldname");
		String disoldname = request.getParameter("disoldname");
		String oldlevel = request.getParameter("conlevel");
		String ill = request.getParameter("ill");
		String dis = request.getParameter("dis");
		String level = request.getParameter("level");
		DBUtil_BO db = new DBUtil_BO();
		try{
			db.getSt("update con set ill=?,dis=?,level=? where ill=?,dis=?,level=?");
			db.st.setString(1,illoldname);
			db.st.setString(2,disoldname);
			if(oldlevel.equals("��Ѩ")){
				db.st.setInt(3,1);
			}else{
				db.st.setInt(3,0);
			}
			db.st.setString(4,ill);
			db.st.setString(5,dis);
			if(level.equals("��Ѩ")){
				db.st.setInt(6,1);
			}else{
				db.st.setInt(6,0);
			}
			db.getRs();
		}catch(Exception e){
			System.out.println("�޸�ʧ��");
		}
		
		try {
			db.realseSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("con_look_jdbc").forward(request,response);
	}
	public void init() throws ServletException {
		
	}

}
