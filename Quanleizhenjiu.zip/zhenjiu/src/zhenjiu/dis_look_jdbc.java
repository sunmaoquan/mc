package zhenjiu;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.Clabean;
import Bean.Disbean;
import Utils.DBUtil_BO;

public class dis_look_jdbc extends HttpServlet {

	public dis_look_jdbc() {
		super();
	}

	public void destroy() {
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		 
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		
		DBUtil_BO db = new DBUtil_BO();
		
		try {
			db.getRs("select  dis.num as num,clas,name,dingwei,jiepao,cifa,zhuzhi,x,y from dis,cla where dis.num=cla.clasnum order by num");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Disbean> classlist = new ArrayList<Disbean>();
		try {
			while(db.rs.next()){
				Disbean disbean = new Disbean();
				disbean.setCla(db.rs.getString("clas"));
				disbean.set(db.rs);
				classlist.add(disbean);
			}
			try {
				db.getRs("select * from cla order by clasnum");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<Clabean> clalist = new ArrayList<Clabean>();
			while(db.rs.next()){
				Clabean clabean = new Clabean();
				clabean.setClasname(db.rs.getString("clas"));
				clabean.setNum(db.rs.getInt("clasnum"));
				clalist.add(clabean);
			}
			session.setAttribute("clalist", clalist);
			session.setAttribute("classlist", classlist);
			
			try {
				db.realseSource();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("/rot_dis.jsp").forward(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void init() throws ServletException {
		
	}

}
