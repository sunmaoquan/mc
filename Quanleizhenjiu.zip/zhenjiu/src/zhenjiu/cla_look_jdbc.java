package zhenjiu;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.Clabean;
import Utils.DBUtil_BO;

public class cla_look_jdbc extends HttpServlet {
	
	public cla_look_jdbc() {
		super();
	}

	public void destroy() {
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		 
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		DBUtil_BO db = new DBUtil_BO();
		try {
			db.getRs("select * from cla order by clasnum");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Clabean> clalist = new ArrayList<Clabean>();
		try{
			while(db.rs.next()){
				Clabean clabean = new Clabean();
				clabean.setClasname(db.rs.getString("clas"));
				clalist.add(clabean);
			}
			session.setAttribute("clalist",clalist);
			
			db.realseSource();
			
			request.getRequestDispatcher("/rot_cla.jsp").forward(request,response);
		}catch(Exception e){
			System.out.println("���ݿ������������������");
		}
	}
	public void init() throws ServletException {
		
	}

}
