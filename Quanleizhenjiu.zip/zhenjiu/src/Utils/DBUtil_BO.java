package Utils;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;


public class DBUtil_BO {   
    public Connection conn = null;
    public PreparedStatement st = null;
    public ResultSet rs = null;
    public DBUtil_BO() {
        super();
        this.conn = C3p0Utils.getConnection();
    }
    public void getSt(String sql) throws Exception{
    	try {
			st = (PreparedStatement) conn.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			realseSource();
		}
    }
    public void getRs() throws Exception{
    	try {
			rs = st.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			realseSource();
		}
    } 
    public void getRs(String sql) throws Exception{
    	try {
    		getSt(sql);
			rs = st.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			realseSource();
		}
    }
    public void realseSource() throws Exception{        
        C3p0Utils.close(this.conn,this.st,this.rs);
    }
}