package Utils;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;


public class C3p0Utils {
	//ͨ����ʶ����������Ӧ���ӳ�
    static ComboPooledDataSource dataSource=new ComboPooledDataSource("mysql");
    //�����ӳ���ȡ��һ������
    public static Connection getConnection(){
        try {
            return (Connection) dataSource.getConnection();
            
        } catch (Exception e) {
            System.out.println(e);          
        }
		return null;
    }    
    //�ͷ����ӻ����ӳ�
     public static void close(Connection conn,PreparedStatement pst,ResultSet rs) throws Exception{  
            if(rs!=null){  
                try {  
                    rs.close();  
                } catch (SQLException e) {  
                    throw new Exception("���ݿ����ӹرճ���!", e);            
                }  
            }  
            if(pst!=null){  
                try {  
                    pst.close();  
                } catch (SQLException e) {  
                    throw new Exception("���ݿ����ӹرճ���!", e);    
                }  
            }  
      
            if(conn!=null){  
                try {  
                    conn.close();  
                } catch (SQLException e) {  
                    throw new Exception("���ݿ����ӹرճ���!", e);    
                }  
            }  
        }  
}
